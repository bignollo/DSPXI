﻿def display( s ) :
	'''Display an argument value.'''
	print( s )

display( display.__doc__ )

display( r'C:\Program Files' )

display( '\nHello' + ' Python' )

display( 'Python In Easy Steps\n' [ 7 : ] )

display( 'P' in 'Python' )
display( 'p' in 'Python' )
