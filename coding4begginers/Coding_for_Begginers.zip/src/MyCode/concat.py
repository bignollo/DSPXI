name = input( 'Please enter your name: ' )
print( 'Hello ' + name , end=' ' ) 
print( '- Welcome to Coding for Beginners' )
print( 'Remember to have fun ' + name + '!' )
