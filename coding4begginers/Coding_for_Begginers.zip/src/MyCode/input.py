name = input( 'Please enter your name: ' )
print( 'Hello' , name )
print( 'Welcome to Coding for Beginners' )
print( 'Remember to have fun' , name , '!' )
