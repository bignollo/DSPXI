var = 8
print( var )
var = 3.142
print( var )
var = 'Coding for Beginners in easy steps'
print( var )
var = True
print( var )
