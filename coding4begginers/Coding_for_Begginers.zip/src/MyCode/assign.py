﻿a = 8
b = 4
print( 'Assign Values:\t' ,'a =' , a , '\tb =' , b )

a += b
print( 'Add & Assign:\t' ,'a =' , a , '\t(8 += 4)' )

a -= b
print( 'Subtract & Assign:\t' ,'a =' , a , '\t(12 - 4)' )

a *= b
print( 'Multiply & Assign:\t' ,'a =' , a , '\t(8 x 4)' )

a /= b
print( 'Divide & Assign:\t' ,'a =' , a , '\t(32 ÷ 4)' )

a %= b
print( 'Modulus & Assign:\t' ,'a =' , a , '\t(8 % 4)' )
