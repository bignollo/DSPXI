days = ( 'Mon' , 'Tue' , 'Wed' , 'Thu' , 'Fri' , 'Sat' , 'Sun' )
print( 'days:' , type( days ) )

print( 'Days of the week:' , days )
print( 'No. of days in week:' , len( days ) )
print( 'Start day of week:' , days[ 0 ] )

user = ( 'John' , 'Doe' , 'Paris' , '555-1234' ) 
print( 'Name:' , user[ 0 ] , user[ 1 ] )
print( 'Phone:' , user[ 3 ] )





