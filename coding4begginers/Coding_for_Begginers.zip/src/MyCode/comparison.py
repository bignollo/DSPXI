﻿nil = 0
num = 0
top = 1
cap = 'A'
low = 'a'

print( 'Equality : \t' , nil , '==' , num , nil == num )
print( 'Equality : \t' , cap , '==' , low , cap == low )
print( 'Inequality :\t' , nil , '!=' , top , nil != top )

print( 'Greater :  \t' , nil , '>' , top , nil > top )
print( 'Lesser :    \t' , nil , '<' , top , nil < top )

print( 'More Or Equal :\t' , nil , '>=' , num , nil >= num )
print( 'Less or Equal :\t' , top , '<=' , num , top <= num )
