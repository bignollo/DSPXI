﻿class Polygon :
	width = 0
	height = 0
	def set_values( self , width , height ) :
		Polygon.width = width
		Polygon.height = height