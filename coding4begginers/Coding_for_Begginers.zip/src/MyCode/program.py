# A function to display a greeting
def greet( reader ) :
    print( 'Welcome to Coding for Beginners' , reader )

greet( input( 'Enter your name:' ) )
