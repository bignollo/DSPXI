﻿for i in range( 1 , 4 ) :

	for j in range( 1 , 4 ) :

		print( 'Running i =' , i , ' j =' , j )