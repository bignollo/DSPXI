﻿title = 'Coding for Beginners in easy steps'
print( titel )