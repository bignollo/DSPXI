race='Daytona 500'
print( race , 'is' , type( race ) )

kilo=1000
print( kilo , 'is' , type( kilo ) )

temp=98.6
print( temp , 'is' , type( temp ) )

flag=True
print( flag , 'is' , type( flag ) )

flag = 4 > 8
print( flag , 'is' , type( flag ) )
