﻿class Mouse :

	'''A class to define Mouse properties.'''

	def talk( self ) :
		print( '\nMouse Says: Squeak!' )

	def coat( self ) :
		print( 'Mouse Wears: Fur' )
