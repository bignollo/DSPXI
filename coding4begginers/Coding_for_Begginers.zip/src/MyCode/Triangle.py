﻿from Polygon import *

class Triangle( Polygon ) :
	def area( self ) :
		return ( self.width * self.height ) / 2