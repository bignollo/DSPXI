﻿i = 1

while i < 4 :
	print( 'Outer Loop Iteration:' , i )
	i += 1

	j = 1
	while j < 4 :
		print( '\tInner Loop Iteration:' , j )
		j += 1

 
	
