﻿title = 'Coding for Beginners In Easy Steps'

try :
	print( titel )

except NameError as msg :
	print( msg )








