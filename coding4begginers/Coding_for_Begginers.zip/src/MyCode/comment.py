# Initialize program status
running = True
print( 'Run state: ', running )

