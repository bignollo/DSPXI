﻿print( 'Coding for Beginners in easy steps  )
