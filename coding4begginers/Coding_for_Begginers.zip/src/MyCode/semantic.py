﻿num = 3
print( 'Result: ' , num * 8 + 4 )
